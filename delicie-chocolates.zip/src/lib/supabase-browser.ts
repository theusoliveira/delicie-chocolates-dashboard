import { createBrowserClient } from '@supabase/ssr'

/**
 * Cliente Supabase para uso em Client Components.
 * Gerencia a sessão via cookies automaticamente no browser.
 */
export function createSupabaseBrowserClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )
}
